let mortos = [
    {
        id: 1,
        nome: "Maria Silva",
        tamanho: "1,75 metros",
        causa: " acidente de trabalho",
        idade: 21
    }
];



module.exports = { mortos };